"""Analyze sample output to understand patterns."""
import csv
import json
from collections import Counter, defaultdict

# Parse sample output
with open("dataset/sample_output.csv", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

# Parse sample requests
with open("dataset/sample_deletion_requests.csv", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    requests = {r["case_id"]: r for r in reader}

# Status distribution
statuses = Counter(r["deletion_status"] for r in rows)
print("Status distribution:", dict(statuses))
print()

# Analyze each case
for r in rows:
    steps = json.loads(r["steps_json"])
    case = requests.get(r["case_id"], {})
    systems = set()
    ops_by_phase = defaultdict(list)
    for s in steps:
        systems.add(s["system_id"])
        phase = s["phase"]
        ops_by_phase[phase].append(f"{s['operation']}({s['system_id']}/{s['resource_id']})")
    evidence_ids = set(s.get("evidence_id", "") for s in steps if s.get("evidence_id"))
    
    print(f"--- {r['case_id']}: {r['deletion_status']} (reported: {case.get('reported_status','?')}) ---")
    print(f"  Email: {case.get('email','?')}")
    print(f"  Steps: {len(steps)} | Systems: {systems}")
    print(f"  Evidence: {evidence_ids}")
    for phase in ["FINDING", "REMEDIATION", "VERIFICATION"]:
        if phase in ops_by_phase:
            print(f"  {phase}: {ops_by_phase[phase]}")
    print()

# Analyze what evidence files are used
print("\n=== Evidence usage ===")
evidence_usage = Counter()
for r in rows:
    steps = json.loads(r["steps_json"])
    for s in steps:
        eid = s.get("evidence_id", "")
        if eid:
            evidence_usage[eid] += 1
print("Evidence usage:", evidence_usage.most_common(20))

# Analyze COMPLETE cases pattern
print("\n=== COMPLETE case patterns ===")
for r in rows:
    if r["deletion_status"] == "COMPLETE":
        steps = json.loads(r["steps_json"])
        ops = [f"{s['operation']}({s['system_id']}/{s['resource_id']})" for s in steps]
        evidence = [s.get("evidence_id","") for s in steps]
        print(f"  {r['case_id']}: {ops}")
        print(f"    evidence: {evidence}")
