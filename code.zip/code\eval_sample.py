"""
Evaluate code/main.py against dataset/sample_deletion_requests.csv and dataset/sample_output.csv
"""
import sys
import csv
import json
from pathlib import Path

# Add code dir to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from main import (
    load_csv, load_deletion_rules, load_user_identities, load_audit_log,
    load_system_activity, IdentityResolver, ActivityAnalyzer, EvidenceIndex,
    process_case
)

def run_evaluation():
    print("Loading data for sample evaluation...")
    deletion_rules = load_deletion_rules()
    users_by_id, users_by_email, users_by_hash = load_user_identities()
    audit_log = load_audit_log()
    activities = load_system_activity()
    sample_requests = load_csv("sample_deletion_requests.csv")
    sample_output = load_csv("sample_output.csv")
    ground_truth = {r["case_id"]: r for r in sample_output}

    identity_resolver = IdentityResolver(users_by_id, users_by_email, users_by_hash, audit_log)
    activity_analyzer = ActivityAnalyzer(activities)
    evidence_index = EvidenceIndex()
    evidence_index.build()

    total_cases = len(sample_requests)
    status_matches = 0
    exact_step_matches = 0
    total_expected_steps = 0
    total_matched_steps = 0

    print(f"\nEvaluating {total_cases} sample cases...")
    for case in sample_requests:
        cid = case["case_id"]
        pred = process_case(case, identity_resolver, evidence_index, activity_analyzer, deletion_rules)
        gt = ground_truth[cid]

        pred_status = pred["deletion_status"]
        gt_status = gt["deletion_status"]
        status_match = (pred_status == gt_status)
        if status_match:
            status_matches += 1

        pred_steps = json.loads(pred["steps_json"])
        gt_steps = json.loads(gt["steps_json"])

        total_expected_steps += len(gt_steps)
        # Compare step details
        steps_match = (pred_steps == gt_steps)
        if steps_match:
            exact_step_matches += 1

        print(f"Case {cid}: Status: {'[OK]' if status_match else '[FAIL]'} (Pred: {pred_status}, GT: {gt_status}) | Steps: {len(pred_steps)} vs {len(gt_steps)} expected {'[OK]' if steps_match else '[FAIL]'}")
        if not status_match or not steps_match:
            if not status_match:
                print(f"   Status mismatch: {pred_status} vs {gt_status}")
            if not steps_match:
                print(f"   Pred steps: {json.dumps(pred_steps)[:150]}...")
                print(f"   GT steps:   {json.dumps(gt_steps)[:150]}...")

    print("\n" + "="*50)
    print(f"Status Accuracy: {status_matches}/{total_cases} ({status_matches/total_cases*100:.1f}%)")
    print(f"Exact Steps Match: {exact_step_matches}/{total_cases} ({exact_step_matches/total_cases*100:.1f}%)")
    print("="*50)

if __name__ == "__main__":
    run_evaluation()
