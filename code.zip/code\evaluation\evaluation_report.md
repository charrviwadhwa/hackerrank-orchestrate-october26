# Evaluation Report: Ghost Data Still Exists Deletion Audit Agent

## 1. Overview
This report evaluates the performance of the AI-powered deletion audit agent on the **HackerRank Orchestrate (October 2026)** benchmark dataset. The audit agent analyzes deletion requests against multi-system evidence (databases, SQL replicas, JSON snapshot bundles, structured event logs, text handover logs, and PDF documents) to determine whether data deletions are compliant at the designated `audit_at` cutoff time.

---

## 2. Evaluation Metrics on Sample Benchmark (32 Public Requests)

| Metric Category | Metric | Score | Details |
|---|---|---|---|
| **Case-Level Status Accuracy** | Overall Deletion Status | **87.50%** | 28 / 32 cases exactly predicted (`COMPLETE`, `INCOMPLETE`, `NOT_APPLICABLE`) |
| **Field-Level Accuracy** | `evidence_id` Accuracy | **96.23%** | 153 / 159 compared step fields |
| | `phase` Accuracy | **90.57%** | 144 / 159 compared step fields |
| | `state` Accuracy | **78.62%** | 125 / 159 compared step fields |
| | `operation` Accuracy | **76.73%** | 122 / 159 compared step fields |
| | `system_id` Accuracy | **77.99%** | 124 / 159 compared step fields |
| | `resource_id` Accuracy | **73.58%** | 117 / 159 compared step fields |
| **Sequence Accuracy** | Exact JSON Array Match | **31.25%** | 10 / 32 cases with 100% exact multi-step array matching |

---

## 3. Participant-Created Evaluation Cases

To rigorously test edge cases not fully exercised by the public sample, we created three comprehensive evaluation cases:

### Custom Case 1: `custom_case_01` (Multi-Regional Cross-Service Replication Drift)
* **Scenario**: A user requests complete erasure of their account and downstream profiles. The primary database successfully executes deletion, but a regional read replica in `eu-west-1` fails to receive the replication stream, leaving the user profile intact in `customer_profiles_failover_replica`. Concurrently, an active data flow connector continuously indexes profiles back into `search_service`.
* **Input Request**:
  ```csv
  case_id,email,requested_at,reported_status,reported_at,audit_at,request_text
  custom_case_01,marcus.vance@techcorp.io,2026-09-01T10:00:00Z,COMPLETE,2026-09-02T10:00:00Z,2026-09-15T12:00:00Z,"Please delete my account and ensure all copies are removed from European search and backup systems."
  ```
* **Expected Output**:
  - `deletion_status`: `INCOMPLETE`
  - `steps_json`:
    ```json
    [
      {"step_no": 1, "phase": "FINDING", "system_id": "account_service", "resource_id": "account_9821", "operation": "REPORT_REMAINING_RECORD", "state": "PRESENT", "evidence_id": "evidence_54"},
      {"step_no": 2, "phase": "FINDING", "system_id": "integration_service", "resource_id": "data_flow_4102", "operation": "REPORT_ACTIVE_DATA_FLOW", "state": "ACTIVE", "evidence_id": "evidence_92"},
      {"step_no": 3, "phase": "REMEDIATION", "system_id": "integration_service", "resource_id": "data_flow_4102", "operation": "DISABLE_DATA_FLOW", "state": "DISABLED", "evidence_id": ""},
      {"step_no": 4, "phase": "REMEDIATION", "system_id": "account_service", "resource_id": "account_9821", "operation": "DELETE_RECORD", "state": "ABSENT", "evidence_id": ""},
      {"step_no": 5, "phase": "VERIFICATION", "system_id": "account_service", "resource_id": "account_9821", "operation": "VERIFY_RECORD_ABSENT", "state": "ABSENT", "evidence_id": ""},
      {"step_no": 6, "phase": "VERIFICATION", "system_id": "integration_service", "resource_id": "data_flow_4102", "operation": "VERIFY_DATA_FLOW_DISABLED", "state": "DISABLED", "evidence_id": ""}
    ]
    ```
* **Rationale**: The agent must disable the active data flow connector prior to deleting the replica record, preventing automatic recreation during remediation.

---

### Custom Case 2: `custom_case_02` (Legal Retention Hold & Account Tombstone Compliance)
* **Scenario**: A user requests account deletion, but their transaction history is subject to an active legal hold (`LEGAL_HOLD_RECORD`), while the identity system created an `ACCOUNT_TOMBSTONE`. The deletion policy mandates retaining the legal audit log, redacting all PII from the tombstone while keeping the immutable `subject_reference`.
* **Input Request**:
  ```csv
  case_id,email,requested_at,reported_status,reported_at,audit_at,request_text
  custom_case_02,elena.rostova@nexus.org,2026-08-15T09:00:00Z,COMPLETE,2026-08-17T09:00:00Z,2026-09-01T12:00:00Z,"I request account deletion. I understand certain financial audit logs may need to be retained for statutory compliance."
  ```
* **Expected Output**:
  - `deletion_status`: `COMPLETE`
  - `steps_json`:
    ```json
    [
      {"step_no": 1, "phase": "VERIFICATION", "system_id": "account_service", "resource_id": "account_1402", "operation": "VERIFY_RECORD_ABSENT", "state": "ABSENT", "evidence_id": "evidence_51"},
      {"step_no": 2, "phase": "VERIFICATION", "system_id": "security_service", "resource_id": "audit_record_8110", "operation": "VERIFY_RECORD_PRESENT", "state": "PRESENT", "evidence_id": "evidence_51"},
      {"step_no": 3, "phase": "VERIFICATION", "system_id": "identity_service", "resource_id": "tombstone_702", "operation": "VERIFY_RECORD_REDACTED", "state": "REDACTED", "evidence_id": "evidence_51"}
    ]
    ```
* **Rationale**: Verifies that the agent correctly honors the retention rule without raising false positive findings on required retained records, while confirming that tombstone direct identifiers are redacted.

---

### Custom Case 3: `custom_case_03` (Non-Deletion Request — Data Access / Portability)
* **Scenario**: A user requests a copy of their personal data and asks how their data is stored, without requesting account erasure or termination.
* **Input Request**:
  ```csv
  case_id,email,requested_at,reported_status,reported_at,audit_at,request_text
  custom_case_03,samir.patel@horizon.net,2026-09-10T14:00:00Z,NOT_STARTED,2026-09-11T14:00:00Z,2026-09-20T12:00:00Z,"Under GDPR Article 15, please provide a full export of all personal data and order records you have collected about me."
  ```
* **Expected Output**:
  - `deletion_status`: `NOT_APPLICABLE`
  - `steps_json`: `[]`
* **Rationale**: Tests intent classification to ensure non-deletion requests (access, portability, rectification) are not processed as deletion audits, strictly returning `NOT_APPLICABLE` with `steps_json=[]` per §6.3.

---

## 4. Failures Found and Improvements Made

### 1. Nested JSON Extraction Gaps
* **Failure Found**: `evidence_92` (`service_resource_export_*.json`) structured services as nested dictionaries (`service_exports -> system_name -> records`), and `evidence_51` used `snapshots[].records[]`. The initial parser only inspected top-level arrays, completely missing 36 critical evidence records and resulting in 0-step outputs for cases 21–32.
* **Improvement Made**: Implemented a recursive JSON tree walker that extracts any nested object containing a `resource_id`, correctly unpacking inner objects (`profile`, `hits.documents`, `tickets`, `connectors`, `audit_records`).

### 2. Multi-Line Correlation in Event Logs
* **Failure Found**: Observability logs (such as `resource_lookup_trace_*.log` and `structured_service_events_*.log`) emit lookup events across multiple lines sharing a common `trace_id`. The initial line-by-line parser evaluated lines in isolation, missing the link between lookup keys (`email`/`subject_ref`) and resulting status codes (`http_status=404`).
* **Improvement Made**: Implemented trace-group aggregation that unifies all fields sharing a `trace_id`, joining lookup queries with completion statuses and timestamps.

### 3. PDF Decompression & Decoding
* **Failure Found**: Support attachments (`delivery_correction_attachment.pdf`) were initially unparsed because standard third-party PDF extraction libraries were unavailable.
* **Improvement Made**: Developed a native pure-Python stream decompressor supporting ReportLab's dual-filter `[ /ASCII85Decode /FlateDecode ]` streams using `base64.a85decode(..., adobe=True)` and `zlib.decompress`, enabling complete text and identifier extraction without external dependencies.

### 4. Grounding of Evidence IDs in Remediation vs Verification
* **Failure Found**: The initial generator assigned evidence IDs to verification steps even in `INCOMPLETE` cases.
* **Improvement Made**: Strictly adhered to AGENTS.md §6.3 and §6.6: `evidence_id` is populated only for proven `COMPLETE` cases and `FINDING` steps. In `INCOMPLETE` cases, all post-remediation verification and remediation steps are assigned `evidence_id: ""`.
