"""
Evaluation Runner for Ghost Data Still Exists
Runs benchmark evaluation on sample dataset and verifies output validity.
"""
import sys
import os
import csv
import json
from pathlib import Path

# Paths
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(REPO_ROOT / "code"))

from main import (
    load_csv, load_deletion_rules, load_user_identities, load_audit_log,
    load_system_activity, IdentityResolver, ActivityAnalyzer, EvidenceIndex,
    process_case
)

def run_evaluation():
    print("=" * 60)
    print("Running Ghost Data Agent Evaluation Benchmark")
    print("=" * 60)

    deletion_rules = load_deletion_rules()
    users_by_id, users_by_email, users_by_hash = load_user_identities()
    audit_log = load_audit_log()
    activities = load_system_activity()
    sample_requests = load_csv("sample_deletion_requests.csv")
    sample_output = load_csv("sample_output.csv")
    ground_truth = {r["case_id"]: r for r in sample_output}

    identity_resolver = IdentityResolver(users_by_id, users_by_email, users_by_hash, audit_log)
    activity_analyzer = ActivityAnalyzer(activities)
    evidence_index = EvidenceIndex()
    evidence_index.build()

    total = len(sample_requests)
    status_correct = 0
    seq_correct = 0
    total_steps = 0
    field_matches = {"phase": 0, "system_id": 0, "resource_id": 0, "operation": 0, "state": 0, "evidence_id": 0}

    for case in sample_requests:
        cid = case["case_id"]
        pred = process_case(case, identity_resolver, evidence_index, activity_analyzer, deletion_rules)
        gt = ground_truth[cid]

        p_status = pred["deletion_status"]
        g_status = gt["deletion_status"]
        if p_status == g_status:
            status_correct += 1

        p_steps = json.loads(pred["steps_json"])
        g_steps = json.loads(gt["steps_json"])

        if p_steps == g_steps:
            seq_correct += 1

        for p, g in zip(p_steps, g_steps):
            for f in field_matches:
                if p.get(f) == g.get(f):
                    field_matches[f] += 1
            total_steps += 1

    print(f"\nResults on {total} sample cases:")
    print(f"  Case-level Status Accuracy: {status_correct}/{total} ({status_correct/total*100:.2f}%)")
    print(f"  Sequence Exact Match: {seq_correct}/{total} ({seq_correct/total*100:.2f}%)")
    print(f"  Compared steps: {total_steps}")
    for f, count in field_matches.items():
        print(f"    Field {f} accuracy: {count}/{total_steps} ({count/total_steps*100:.2f}%)")
    print("\nBenchmark completed successfully.")

if __name__ == "__main__":
    run_evaluation()
