# Token Usage Report

## Run Summary

- **Date**: 2026-10-25T11:40:31.456571
- **Total cases processed**: 518

## Model Usage

| Metric | Value |
|---|---|
| Provider | Google AI (Gemini) |
| Model | gemini-2.0-flash |
| API Calls | 0 |
| Input Tokens | 0 |
| Output Tokens | 0 |
| Total Tokens | 0 |
| Avg Tokens/Request | 0 |
| Estimated Cost | $0.0000 |
