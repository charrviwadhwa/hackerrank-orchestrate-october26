import csv
import json

samples = list(csv.DictReader(open('dataset/sample_deletion_requests.csv', encoding='utf-8-sig')))
outputs = {r['case_id']: r for r in csv.DictReader(open('dataset/sample_output.csv', encoding='utf-8-sig'))}
users_by_email = {u['email'].lower(): u for u in csv.DictReader(open('dataset/user_identities.csv', encoding='utf-8-sig'))}
audit_by_uid = {}
for a in csv.DictReader(open('dataset/user_audit_log.csv', encoding='utf-8-sig')):
    audit_by_uid.setdefault(a['user_id'], []).append(a)

for s in samples:
    cid = s['case_id']
    out = outputs[cid]
    if out['deletion_status'] != 'INCOMPLETE':
        continue
    steps = json.loads(out['steps_json'])
    findings = [st['resource_id'] for st in steps if st['phase'] == 'FINDING']
    verifs = [(st['system_id'], st['resource_id'], st['operation']) for st in steps if st['phase'] == 'VERIFICATION']
    verif_res = [v[1] for v in verifs]
    extra_verifs = [v for v in verifs if v[1] not in findings]
    print(f"{cid}: {len(findings)} findings ({findings}) -> {len(verifs)} verifs ({verif_res})")
    print(f"   Extra verifs (not in findings): {extra_verifs}")
